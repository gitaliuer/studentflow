"""Integration tests. Database is always copied to tmp_path; original ак.db is untouched."""

import re
import shutil
import sqlite3

import pytest
from fastapi.testclient import TestClient

import app as server

HASH = server.PASSWORDS.hash("CorrectPassword123!")


@pytest.fixture()
def site(tmp_path, monkeypatch):
    copied_db = tmp_path / "ак.db"
    shutil.copy2(server.BASE_DIR / "ак.db", copied_db)
    monkeypatch.setattr(server, "DB_PATH", copied_db)
    with sqlite3.connect(copied_db) as conn:
        conn.execute("UPDATE users SET password_hash = ?", (HASH,))
    yield copied_db


def csrf_value(response):
    match = re.search(r'name="csrf_token" value="([^\"]+)"', response.text)
    assert match, "CSRF token not found in form"
    return match.group(1)


def login(username):
    client = TestClient(server.app)
    response = client.get("/login")
    token = csrf_value(response)
    response = client.post(
        "/login",
        data={"username": username, "password": "CorrectPassword123!", "csrf_token": token},
        follow_redirects=False,
    )
    assert response.status_code == 303
    assert response.headers["location"] == "/dashboard"
    return client


def csrf_for(client, path):
    return csrf_value(client.get(path))


def query(path, sql, args=()):
    with sqlite3.connect(path) as conn:
        return conn.execute(sql, args).fetchall()


def test_original_data_is_present(site):
    assert len(query(site, "SELECT id FROM users")) == 3
    assert query(site, "SELECT score FROM grades") == [(92,)]
    assert query(site, "PRAGMA integrity_check") == [("ok",)]
    assert query(site, "PRAGMA foreign_key_check") == []


def test_login_and_home_redirect(site):
    client = TestClient(server.app)
    assert client.get("/admin", follow_redirects=False).headers["location"] == "/login"
    page = client.get("/login")
    assert "Қош келдіңіз" in page.text
    bad = client.post("/login", data={"username": "student1", "password": "wrong",
                                        "csrf_token": csrf_value(page)}, follow_redirects=True)
    assert "Логин немесе құпиясөз дұрыс емес" in bad.text
    student = login("student1")
    result = student.get("/dashboard", follow_redirects=True)
    assert result.status_code == 200
    assert "Менің бағаларым" in result.text
    assert "92" in result.text
    token = csrf_value(result)
    logout = student.post("/logout", data={"csrf_token": token}, follow_redirects=False)
    assert logout.headers["location"] == "/login"
    assert student.get("/student", follow_redirects=False).status_code == 303


def test_role_boundaries(site):
    teacher = login("teacher1")
    student = login("student1")
    admin = login("admin")
    for client, forbidden in [(teacher, "/admin"), (student, "/teacher"),
                              (student, "/admin"), (admin, "/teacher"), (admin, "/student")]:
        response = client.get(forbidden)
        assert response.status_code == 403, (forbidden, response.text[:300])
    assert admin.get("/admin").status_code == 200
    assert teacher.get("/teacher").status_code == 200
    assert student.get("/student").status_code == 200
    no_csrf = teacher.post("/teacher/grades", data={"student_id": 1, "subject_id": 1, "score": 99})
    assert no_csrf.status_code == 403
    assert query(site, "SELECT score FROM grades") == [(92,)]


def test_admin_crud_users_and_subjects(site):
    admin = login("admin")
    csrf = csrf_for(admin, "/admin")
    add = admin.post("/admin/users", data={"username": "newstudent", "full_name": "Жаңа Студент",
        "role": "student", "password": "NewPassword123!", "group_name": "ИС-202", "csrf_token": csrf},
        follow_redirects=True)
    assert add.status_code == 200
    assert "newstudent" in add.text
    user_id = query(site, "SELECT id FROM users WHERE username = 'newstudent'")[0][0]
    assert query(site, "SELECT group_name FROM students WHERE user_id = ?", (user_id,)) == [("ИС-202",)]

    edit_url = f"/admin/users/{user_id}/edit"
    edit_token = csrf_for(admin, edit_url)
    edit = admin.post(edit_url, data={"username": "newstudent", "full_name": "Жаңа Адам",
        "role": "student", "password": "", "group_name": "ИС-203", "csrf_token": edit_token},
        follow_redirects=True)
    assert "Жаңа Адам" in edit.text
    assert query(site, "SELECT group_name FROM students WHERE user_id = ?", (user_id,)) == [("ИС-203",)]

    create_sub = admin.post("/admin/subjects", data={"name": "Алгоритмдер", "teacher_id": 2,
        "csrf_token": csrf_for(admin, "/admin")}, follow_redirects=True)
    assert "Алгоритмдер" in create_sub.text
    sub_id = query(site, "SELECT id FROM subjects WHERE name = 'Алгоритмдер'")[0][0]
    update_sub = admin.post(f"/admin/subjects/{sub_id}/edit", data={"name": "Алгоритмдер 2",
        "teacher_id": 2, "csrf_token": csrf_for(admin, f"/admin/subjects/{sub_id}/edit")},
        follow_redirects=True)
    assert "Алгоритмдер 2" in update_sub.text
    admin.post(f"/admin/subjects/{sub_id}/delete", data={"csrf_token": csrf_for(admin, "/admin")})
    assert not query(site, "SELECT 1 FROM subjects WHERE id=?", (sub_id,))
    admin.post(f"/admin/users/{user_id}/delete", data={"csrf_token": csrf_for(admin, "/admin")})
    assert not query(site, "SELECT 1 FROM users WHERE id=?", (user_id,))
    assert query(site, "PRAGMA foreign_key_check") == []


def test_grade_operations_and_ownership(site):
    teacher = login("teacher1")
    token = csrf_for(teacher, "/teacher")
    added = teacher.post("/teacher/grades", data={"student_id": 1, "subject_id": 1,
        "score": 98, "csrf_token": token}, follow_redirects=True)
    assert added.status_code == 200
    assert "98" in added.text
    grade_id = query(site, "SELECT MAX(id) FROM grades")[0][0]
    grade_url = f"/teacher/grades/{grade_id}/edit"
    updated = teacher.post(grade_url, data={"score": 89,
        "csrf_token": csrf_for(teacher, grade_url)}, follow_redirects=True)
    assert updated.status_code == 200
    assert query(site, "SELECT score FROM grades WHERE id=?", (grade_id,)) == [(89,)]

    with sqlite3.connect(site) as conn:
        conn.execute("INSERT INTO users(username,password_hash,full_name,role) VALUES('teacher2',?,'Other Teacher','teacher')", (HASH,))
        teacher2_id = conn.execute("SELECT id FROM users WHERE username='teacher2'").fetchone()[0]
        conn.execute("INSERT INTO subjects(name,teacher_id) VALUES('Other Subject',?)", (teacher2_id,))
        foreign_subject_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.execute("INSERT INTO grades(student_id,subject_id,score) VALUES(1,?,77)", (foreign_subject_id,))
        foreign_grade_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    teacher2 = login("teacher2")
    assert teacher.get(f"/teacher/grades/{foreign_grade_id}/edit").status_code == 404
    assert teacher.post(f"/teacher/grades/{foreign_grade_id}/delete",
                        data={"csrf_token": csrf_for(teacher, "/teacher")}).status_code == 404
    blocked = teacher.post("/teacher/grades", data={"student_id":1, "subject_id": foreign_subject_id,
        "score":90, "csrf_token": csrf_for(teacher, "/teacher")}, follow_redirects=True)
    assert "дұрыс таңдалмаған" in blocked.text
    assert teacher2.get(f"/teacher/grades/{foreign_grade_id}/edit").status_code == 200

    deleted = teacher.post(f"/teacher/grades/{grade_id}/delete",
        data={"csrf_token": csrf_for(teacher, "/teacher")}, follow_redirects=True)
    assert deleted.status_code == 200
    assert not query(site, "SELECT 1 FROM grades WHERE id=?", (grade_id,))
    assert query(site, "PRAGMA foreign_key_check") == []


def test_student_cannot_see_other_students_results(site):
    with sqlite3.connect(site) as conn:
        conn.execute("INSERT INTO users(username,password_hash,full_name,role) VALUES('student2',?,'Жасырын Студент','student')", (HASH,))
        id2 = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.execute("INSERT INTO students(user_id,group_name) VALUES(?, 'Жасырын-999')", (id2,))
        student2_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.execute("INSERT INTO grades(student_id,subject_id,score) VALUES(?,1,17)", (student2_id,))
    client = login("student1")
    response = client.get("/student")
    assert response.status_code == 200
    assert "92" in response.text
    assert "Жасырын Студент" not in response.text
    assert "Жасырын-999" not in response.text
    assert ">17<" not in response.text


def test_reject_invalid_score_and_guard_history(site):
    teacher = login("teacher1")
    for score in [101, -5]:
        response = teacher.post("/teacher/grades", data={"student_id": 1, "subject_id": 1,
            "score": score, "csrf_token": csrf_for(teacher, "/teacher")}, follow_redirects=True)
        assert "0 мен 100" in response.text
    assert query(site, "SELECT score FROM grades") == [(92,)]
    admin = login("admin")
    blocked_user = admin.post("/admin/users/3/delete", data={"csrf_token": csrf_for(admin, "/admin")},
        follow_redirects=True)
    assert "Студенттің бағалары бар" in blocked_user.text
    blocked_subject = admin.post("/admin/subjects/1/delete", data={"csrf_token": csrf_for(admin, "/admin")},
        follow_redirects=True)
    assert "Бағалары бар пәнді" in blocked_subject.text
    assert query(site, "SELECT count(*) FROM grades")[0][0] == 1


def test_password_hash_not_plaintext(site):
    admin = login("admin")
    token = csrf_for(admin, "/admin")
    admin.post("/admin/users", data={"username": "tempteacher", "full_name": "New Teacher",
        "role": "teacher", "password": "SecurePassword!", "csrf_token": token})
    secret_hash = query(site, "SELECT password_hash FROM users WHERE username='tempteacher'")[0][0]
    assert secret_hash.startswith("$argon2id$")
    assert "SecurePassword!" not in secret_hash
    assert server.PASSWORDS.verify(secret_hash, "SecurePassword!")


@pytest.mark.parametrize("path", ["/lab10", "/lab10/plan", "/lab10/map"])
def test_lab10_requires_login(site, path):
    client = TestClient(server.app)
    response = client.get(path, follow_redirects=False)
    assert response.status_code == 303
    assert response.headers["location"] == "/login"


@pytest.mark.parametrize("username", ["admin", "teacher1", "student1"])
def test_lab10_all_roles_and_database_unchanged(site, username):
    before = site.read_bytes()
    client = login(username)
    for path, expected in [("/lab10", 'id="plan-form"'),
                           ("/lab10/plan", 'id="plan-rows"'),
                           ("/lab10/map", "Architecture Map")]:
        response = client.get(path)
        assert response.status_code == 200
        assert expected.lower() in response.text.lower()
        assert 'href="/lab10"' in response.text
        assert 'href="/lab10/plan"' in response.text
        assert 'href="/lab10/map"' in response.text
    assert site.read_bytes() == before


def test_lab10_does_not_add_server_writes(site):
    client = login("student1")
    before = site.read_bytes()
    for path in ["/lab10", "/lab10/plan", "/lab10/map"]:
        assert client.post(path, data={"hours": 3}).status_code == 405
    assert site.read_bytes() == before


def test_lab10_script_is_separate_and_no_hardcoded_cards(site):
    client = login("student1")
    editor = client.get("/lab10").text
    assert 'id="course-catalog" class="lab-catalog"></div>' in editor
    assert 'src="http://testserver/static/lab10.js"' in editor
    script = client.get("/static/lab10.js")
    assert script.status_code == 200
    assert "localStorage.setItem(STORAGE_KEY" in script.text
    assert "localStorage.getItem(STORAGE_KEY" in script.text
    assert "new FormData(form)" in script.text
