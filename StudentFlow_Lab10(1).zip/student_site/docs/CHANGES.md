# Изменения для лабораторной №10

## Изменены

- README.md
- app.py
- static/style.css
- templates/base.html
- tests/test_app.py

## Добавлены

- docs/LAB10_REPORT.md
- docs/NAVIGATION.md
- docs/SCREENSHOT_SCENARIOS.md
- docs/VERIFICATION.md
- docs/screenshots/README.md
- docs/test_environment_versions.txt
- static/lab10.js
- templates/lab10_editor.html
- templates/lab10_map.html
- templates/lab10_plan.html
- tests/check_lab10_browser.py
- tests/check_lab10_logic.cjs
- tests/render_lab10_fixture.py

## Сохранены

- ак.db: точная копия исходного файла, без смены паролей или схемы.
- Все серверные обработчики №9, SQL и проверки ролей.
- Исходные ролевые страницы, формы редактирования, установка паролей и Windows-скрипты.
- В архив не включены venv, кеши, временные fixtures, секрет сессии и какие-либо пользовательские данные сверх исходной учебной базы.
